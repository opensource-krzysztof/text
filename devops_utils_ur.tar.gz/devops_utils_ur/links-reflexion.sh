download-dpc.txt - https://tinyurl.com/devops-rk-1
build.txt - https://tinyurl.com/devops-rk-2
configure-ur.txt - https://tinyurl.com/devops-rk-3
test_adapter_specific.txt - https://tinyurl.com/devops-rk-4
check_sycl-ls.txt - https://tinyurl.com/devops-rk-5
install.txt - https://tinyurl.com/devops-rk-6
test_adapters.txt - https://tinyurl.com/devops-rk-7
alldeps.txt https://tinyurl.com/devops-rk-8
opencl.txt https://tinyurl.com/devops-rk-9
single_test.sh https://tinyurl.com/devops-rk-10
pythonConfig.txt https://tinyurl.com/devops-rk-11
managed.txt https://tinyurl.com/devops-rk-12
igc-cm 1.0-119.u20.04 latest https://tinyurl.com/devops-rk-14
igc-cm 1.0.120+i1_u20.04 https://tinyurl.com/devops-rk-15
igc-cm 1.0-97.u20.04 https://tinyurl.com/devops-rk-16
igc-cm 1.0.126+i1_u20.04 https://tinyurl.com/devops-rk-17
igc-cm 1.0.91.u30.04 https://tinyurl.com/devops-rk-18
docker pull ghcr.io/intel/llvm/ubuntu2404_intel_drivers:alldeps

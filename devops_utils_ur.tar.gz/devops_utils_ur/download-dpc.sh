wget -O dpcpp_compiler.tar.gz https://github.com/intel/llvm/releases/download/nightly-2025-03-25/sycl_linux.tar.gz
mkdir -p dpcpp_compiler
tar -xvf dpcpp_compiler.tar.gz -C dpcpp_compiler